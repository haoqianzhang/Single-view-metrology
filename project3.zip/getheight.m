function getheight(vX, vY)
vanishline = cross(vX,VY);
